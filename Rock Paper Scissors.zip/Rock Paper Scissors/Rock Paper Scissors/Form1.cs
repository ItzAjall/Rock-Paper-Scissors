﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Rock_Paper_Scissors
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        game gme = new game();

        private void butrock_Click(object sender, EventArgs e)
        {
            meow.player = 1;
            this.Hide();
            gme.Show();
        }

        private void butpaper_Click(object sender, EventArgs e)
        {
            meow.player = 2;
            this.Hide();
            gme.Show();
        }

        private void butsicssors_Click(object sender, EventArgs e)
        {
            meow.player = 3;
            this.Hide();
            gme.Show();
        }
    }
}
