﻿namespace Rock_Paper_Scissors
{
    partial class game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(game));
            this.picpaper = new System.Windows.Forms.PictureBox();
            this.picsicssors = new System.Windows.Forms.PictureBox();
            this.picrock = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.picairock = new System.Windows.Forms.PictureBox();
            this.picaisic = new System.Windows.Forms.PictureBox();
            this.picaipaper = new System.Windows.Forms.PictureBox();
            this.lblgame = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picpaper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picsicssors)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picrock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picairock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picaisic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picaipaper)).BeginInit();
            this.SuspendLayout();
            // 
            // picpaper
            // 
            this.picpaper.BackgroundImage = global::Rock_Paper_Scissors.Properties.Resources.paper;
            this.picpaper.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picpaper.Location = new System.Drawing.Point(520, 141);
            this.picpaper.Name = "picpaper";
            this.picpaper.Size = new System.Drawing.Size(208, 152);
            this.picpaper.TabIndex = 1;
            this.picpaper.TabStop = false;
            this.picpaper.Visible = false;
            // 
            // picsicssors
            // 
            this.picsicssors.BackgroundImage = global::Rock_Paper_Scissors.Properties.Resources.scissors;
            this.picsicssors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picsicssors.Location = new System.Drawing.Point(520, 141);
            this.picsicssors.Name = "picsicssors";
            this.picsicssors.Size = new System.Drawing.Size(208, 152);
            this.picsicssors.TabIndex = 2;
            this.picsicssors.TabStop = false;
            this.picsicssors.Visible = false;
            // 
            // picrock
            // 
            this.picrock.BackgroundImage = global::Rock_Paper_Scissors.Properties.Resources.rock;
            this.picrock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picrock.Location = new System.Drawing.Point(520, 141);
            this.picrock.Name = "picrock";
            this.picrock.Size = new System.Drawing.Size(208, 152);
            this.picrock.TabIndex = 3;
            this.picrock.TabStop = false;
            this.picrock.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(99, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 47);
            this.label2.TabIndex = 5;
            this.label2.Text = "AI Choice";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(520, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 47);
            this.label1.TabIndex = 6;
            this.label1.Text = "Your Choice";
            // 
            // picairock
            // 
            this.picairock.BackgroundImage = global::Rock_Paper_Scissors.Properties.Resources.rock;
            this.picairock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picairock.Location = new System.Drawing.Point(73, 152);
            this.picairock.Name = "picairock";
            this.picairock.Size = new System.Drawing.Size(208, 152);
            this.picairock.TabIndex = 9;
            this.picairock.TabStop = false;
            this.picairock.Visible = false;
            // 
            // picaisic
            // 
            this.picaisic.BackgroundImage = global::Rock_Paper_Scissors.Properties.Resources.scissors;
            this.picaisic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picaisic.Location = new System.Drawing.Point(73, 152);
            this.picaisic.Name = "picaisic";
            this.picaisic.Size = new System.Drawing.Size(208, 152);
            this.picaisic.TabIndex = 8;
            this.picaisic.TabStop = false;
            this.picaisic.Visible = false;
            // 
            // picaipaper
            // 
            this.picaipaper.BackgroundImage = global::Rock_Paper_Scissors.Properties.Resources.paper;
            this.picaipaper.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picaipaper.Location = new System.Drawing.Point(73, 152);
            this.picaipaper.Name = "picaipaper";
            this.picaipaper.Size = new System.Drawing.Size(208, 152);
            this.picaipaper.TabIndex = 7;
            this.picaipaper.TabStop = false;
            this.picaipaper.Visible = false;
            // 
            // lblgame
            // 
            this.lblgame.AutoSize = true;
            this.lblgame.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblgame.Location = new System.Drawing.Point(314, 346);
            this.lblgame.Name = "lblgame";
            this.lblgame.Size = new System.Drawing.Size(0, 47);
            this.lblgame.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(64, 359);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(185, 57);
            this.button1.TabIndex = 11;
            this.button1.Text = "Play Again";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblgame);
            this.Controls.Add(this.picairock);
            this.Controls.Add(this.picaisic);
            this.Controls.Add(this.picaipaper);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.picrock);
            this.Controls.Add(this.picsicssors);
            this.Controls.Add(this.picpaper);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "game";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rock Paper Scissors";
            this.Load += new System.EventHandler(this.game_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picpaper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picsicssors)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picrock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picairock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picaisic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picaipaper)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox picpaper;
        private System.Windows.Forms.PictureBox picsicssors;
        private System.Windows.Forms.PictureBox picrock;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picairock;
        private System.Windows.Forms.PictureBox picaisic;
        private System.Windows.Forms.PictureBox picaipaper;
        private System.Windows.Forms.Label lblgame;
        private System.Windows.Forms.Button button1;
    }
}