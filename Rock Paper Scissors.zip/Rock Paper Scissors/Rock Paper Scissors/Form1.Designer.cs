﻿namespace Rock_Paper_Scissors
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.butpaper = new System.Windows.Forms.Button();
            this.lblchoose = new System.Windows.Forms.Label();
            this.butsicssors = new System.Windows.Forms.Button();
            this.butrock = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // butpaper
            // 
            this.butpaper.BackgroundImage = global::Rock_Paper_Scissors.Properties.Resources.paper;
            this.butpaper.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.butpaper.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butpaper.Location = new System.Drawing.Point(370, 184);
            this.butpaper.Name = "butpaper";
            this.butpaper.Size = new System.Drawing.Size(156, 143);
            this.butpaper.TabIndex = 0;
            this.butpaper.UseVisualStyleBackColor = true;
            this.butpaper.Click += new System.EventHandler(this.butpaper_Click);
            // 
            // lblchoose
            // 
            this.lblchoose.AutoSize = true;
            this.lblchoose.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblchoose.Location = new System.Drawing.Point(315, 99);
            this.lblchoose.Name = "lblchoose";
            this.lblchoose.Size = new System.Drawing.Size(256, 40);
            this.lblchoose.TabIndex = 1;
            this.lblchoose.Text = "Please Choose one";
            // 
            // butsicssors
            // 
            this.butsicssors.BackgroundImage = global::Rock_Paper_Scissors.Properties.Resources.scissors;
            this.butsicssors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.butsicssors.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butsicssors.Location = new System.Drawing.Point(573, 184);
            this.butsicssors.Name = "butsicssors";
            this.butsicssors.Size = new System.Drawing.Size(156, 143);
            this.butsicssors.TabIndex = 2;
            this.butsicssors.UseVisualStyleBackColor = true;
            this.butsicssors.Click += new System.EventHandler(this.butsicssors_Click);
            // 
            // butrock
            // 
            this.butrock.BackgroundImage = global::Rock_Paper_Scissors.Properties.Resources.rock;
            this.butrock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.butrock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butrock.Location = new System.Drawing.Point(161, 184);
            this.butrock.Name = "butrock";
            this.butrock.Size = new System.Drawing.Size(156, 143);
            this.butrock.TabIndex = 3;
            this.butrock.UseVisualStyleBackColor = true;
            this.butrock.Click += new System.EventHandler(this.butrock_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(890, 519);
            this.Controls.Add(this.butrock);
            this.Controls.Add(this.butsicssors);
            this.Controls.Add(this.lblchoose);
            this.Controls.Add(this.butpaper);
            this.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rock Paper Scissors";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button butpaper;
        private System.Windows.Forms.Label lblchoose;
        private System.Windows.Forms.Button butsicssors;
        private System.Windows.Forms.Button butrock;
    }
}
