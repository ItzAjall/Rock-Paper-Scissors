﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Rock_Paper_Scissors
{
    public partial class game : Form
    {
        public game()
        {
            InitializeComponent();
        }
        Random rnd = new Random();
        private void game_Load(object sender, EventArgs e)
        {
            playerchoice();
            AiChoice();
            if (Game(meow.player, meow.Ai) == 0)
            {
                lblgame.Text = "Draw";
            }
            else if (Game(meow.player,meow.Ai) == 1)
            {
                lblgame.Text = "You Win";
                lblgame.ForeColor = Color.Green;
            }
            else if (Game(meow.player, meow.Ai) == 2)
            {
                lblgame.Text = "You Lose!";
                lblgame.ForeColor = Color.Red;
            }
        }
        public void AiChoice()
        {
            meow.Ai = rnd.Next(1,4);
            if (meow.Ai == 1)
            {
                picairock.Visible = true;
            }
            else if (meow.Ai == 2)
            {
                picaipaper.Visible = true;
            }
            else if (meow.Ai == 3)
            {
                picaisic.Visible = true;
            }
        }

        public void playerchoice()
        {
            if (meow.player == 1)
            {
                picrock.Visible = true;
            }
            else if (meow.player == 2)
            {
                picpaper.Visible = true;
            }
            else if (meow.player == 3) 
            {
                picsicssors.Visible = true;
            }
        }

        public int Game(int player,int ai )
        {
            if (player == ai)
            {
                return 0;
            }
            else if (player == 1 && ai == 3)
            {
                return 1;
            }
            else if (player == 2 && ai == 1)
            {
                return 1;
            }
            else if (player == 3 && ai == 2)
            {
                return 1;
            }
            else if (player == 1 && ai == 2)
            {
                return 2;
            }
            else if (player == 2 && ai == 3)
            {
                return 2;
            }
            else if (player == 3 && ai == 1)
            {
                return 2;
            }
            else
            {
                return 5;
            }
                
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            this.Close();
            frm1.Show();
        }
    }
}
