﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rock_Paper_Scissors
{
    internal class meow
    {
        private static int playerchoice = 0;

        public static int player
        {
            get { return playerchoice; }
            set { playerchoice = value; }
        }

        private static int Aichoice = 0;

        public static int Ai
        {
            get { return Aichoice; }
            set { Aichoice = value; }
        }
    }
}
